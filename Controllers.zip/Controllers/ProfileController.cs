using System.Globalization;
using System.Security.Claims;
using DSM.Data;
using DSM.Models;
using DSM.ViewModels;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DSM.Controllers {
    [Authorize]
    public class ProfileController : Controller {
        private readonly ApplicationDatabaseContext _context;
        private readonly PasswordHasher<User> _passwordHasher = new();

        public ProfileController(ApplicationDatabaseContext context) {
            _context = context;
        }

        public async Task<IActionResult> Index() {
            User? user = await CurrentUser();
            if (user == null) {
                return RedirectToAction("SignIn", "Auth");
            }

            return View(ToViewModel(user));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(ProfileViewModel model) {
            User? user = await CurrentUser();
            if (user == null) {
                return RedirectToAction("SignIn", "Auth");
            }

            if (!ModelState.IsValid) {
                model.Id = GetValue(user, "Id")?.ToString();
                model.Role = GetValue(user, "Role")?.ToString();
                model.IsActive = IsActive(user);
                return View(model);
            }

            string username = model.Username.Trim();
            string email = model.Email.Trim().ToLowerInvariant();
            string name = model.Name.Trim();
            object? currentId = GetValue(user, "Id");

            bool usernameExists = await _context.Users.AnyAsync(u => u.Username == username && !Equals(GetValue(u, "Id"), currentId));
            if (usernameExists) {
                ModelState.AddModelError(nameof(model.Username), "This Username Is Already In Use.");
                return View(ToViewModel(user, model));
            }

            bool emailExists = await _context.Users.AnyAsync(u => u.Email == email && !Equals(GetValue(u, "Id"), currentId));
            if (emailExists) {
                ModelState.AddModelError(nameof(model.Email), "This Email Is Already In Use.");
                return View(ToViewModel(user, model));
            }

            user.Username = username;
            user.Email = email;
            user.Name = name;
            if (!string.IsNullOrWhiteSpace(model.Password)) {
                user.Password = _passwordHasher.HashPassword(user, model.Password.Trim());
            }
            await _context.SaveChangesAsync();
            await RefreshSignIn(user);
            TempData["ProfileMessage"] = "Profile updated.";
            return RedirectToAction(nameof(Index));
        }

        private async Task<User?> CurrentUser() {
            string? username = User.Identity?.Name;
            if (string.IsNullOrWhiteSpace(username)) {
                return null;
            }
            return await _context.Users.FirstOrDefaultAsync(u => u.Username == username);
        }

        private ProfileViewModel ToViewModel(User user, ProfileViewModel? current = null) {
            return new ProfileViewModel {
                Id = GetValue(user, "Id")?.ToString(),
                Username = current?.Username ?? user.Username ?? string.Empty,
                Name = current?.Name ?? user.Name ?? string.Empty,
                Email = current?.Email ?? user.Email ?? string.Empty,
                Role = GetValue(user, "Role")?.ToString(),
                IsActive = IsActive(user),
                ProfileIcon = current?.ProfileIcon ?? Request.Cookies["dsm.profileIcon"] ?? "pi-user"
            };
        }

        private async Task RefreshSignIn(User user) {
            var claims = new List<Claim> {
                new(ClaimTypes.NameIdentifier, GetValue(user, "Id")?.ToString() ?? string.Empty),
                new(ClaimTypes.Name, user.Username ?? string.Empty),
                new("DisplayName", user.Name ?? user.Username ?? string.Empty),
                new(ClaimTypes.Email, user.Email ?? string.Empty),
                new(ClaimTypes.Role, GetValue(user, "Role")?.ToString() ?? "user"),
                new("IsActive", IsActive(user).ToString())
            };
            ClaimsIdentity identity = new(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));
        }

        private bool IsActive(User user) {
            object? value = GetValue(user, "IsActive");
            return value is bool b ? b : value == null || bool.TryParse(value.ToString(), out bool parsed) && parsed;
        }

        private static object? GetValue(object target, string propertyName) {
            return target.GetType().GetProperty(propertyName)?.GetValue(target);
        }
    }
}
