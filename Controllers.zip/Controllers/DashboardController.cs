using DSM.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DSM.Controllers {
    [Authorize]
    public class DashboardController : Controller {
        private readonly ApplicationDatabaseContext _context;

        public DashboardController(ApplicationDatabaseContext context) {
            _context = context;
        }

        public async Task<IActionResult> Index() {
            ViewData["Title"] = "Dashboard";
            ViewBag.OrdersCount = await _context.Orders.CountAsync();
            ViewBag.CustomersCount = await _context.Customers.CountAsync();
            ViewBag.CarriersCount = await _context.Carriers.CountAsync();
            ViewBag.SuppliersCount = await _context.Suppliers.CountAsync();
            ViewBag.StocksCount = await _context.Stocks.CountAsync();
            ViewBag.ShippingCount = await _context.Shippings.CountAsync();
            ViewBag.InvoiceCount = await _context.Invoices.CountAsync();
            ViewBag.SupportCount = await _context.SupportTickets.CountAsync();
            return View();
        }
    }
}
